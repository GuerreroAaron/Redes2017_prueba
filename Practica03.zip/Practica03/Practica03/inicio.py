from Redes/practica2.1/Channel.s3 import FuncionS
from Redes/practica2.1/Channel.c3 import Cliente
from Redes/practica2.1/GUI.LoginV import Ventana

if __name__ == '__main__':
     #Instanciamos la Clase
     Cliente() 
     FuncionS()
     Ventana()
     
