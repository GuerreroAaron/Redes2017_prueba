Para ejecutar la practica solo tenemos que correr el archivo Main en la carpeta de Princial

